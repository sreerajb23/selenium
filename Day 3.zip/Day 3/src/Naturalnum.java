
public class Naturalnum {
    public static void main(String args[]) {
            System.out.println("The first 10 natural numbers are:");
        for (int n= 1; n<=10;n++)
        {
            System.out.println(n);
        }
        System.out.println("\n");
    }
}
